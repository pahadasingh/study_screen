const { pathsToModuleNameMapper } = require("ts-jest/dist/config");
const { compilerOptions } = require("./tsconfig.json");

const moduleNameMapper = pathsToModuleNameMapper(compilerOptions.paths, {
  prefix: "<rootDir>/",
});

module.exports = {
  // preset: 'ts-jest',
  preset: "jest-preset-angular",
  roots: ['<rootDir>/src'],
  testMatch: ['**/+(*.)+(spec).+(ts)'],
  setupFilesAfterEnv: ["<rootDir>/src/setupJest.ts"],
  transformIgnorePatterns: [
    "^.+\\.js$"
  ],
  moduleNameMapper,
  silent: true,
  collectCoverage: true,
  coverageReporters: ["lcov", "cobertura"],
  coverageDirectory: "<rootDir>/coverage",
  reporters: [
    "default",
    [
      "jest-junit",
      {
        outputDirectory: "<rootDir>/coverage",
        outputName: "TESTS-jest-ng-seed.xml",
      },
    ],
  ],
};