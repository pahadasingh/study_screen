// import { ComponentFixture, TestBed } from '@angular/core/testing';
// import { RouterTestingModule } from '@angular/router/testing';
// import { provideMockStore, MockStore } from '@ngrx/store/testing';
// import { HttpClientTestingModule } from '@angular/common/http/testing';

// import { AppComponent } from './app.component';
// import { ServiceWorkerModule, SwPush, SwUpdate } from '@angular/service-worker';
// import { NotificationService } from './notifications.service';

// describe('AppComponent', () => {
//   let component: AppComponent;
//   let fixture: ComponentFixture<AppComponent>;
//   // let store: MockStore;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientTestingModule, RouterTestingModule, ServiceWorkerModule.register('', { enabled: false })],
//       declarations: [AppComponent],
//       providers: [
//         MockStore,
//         SwUpdate,
//         SwPush,
//         NotificationService,
//         provideMockStore({}),
//       ],
//     });

//     fixture = TestBed.createComponent(AppComponent);
//     component = fixture.componentInstance;

//     TestBed.inject(MockStore);
//     TestBed.inject(SwUpdate);
//     TestBed.inject(SwPush);
//     TestBed.inject(NotificationService);
//   });

//   it('should create the app', () => {
//     const fixture = TestBed.createComponent(AppComponent);
//     const app = fixture.componentInstance;
//     expect(app).toBeTruthy();
//   });

//   it(`should have as title 'my-project-three-17v'`, () => {
//     const fixture = TestBed.createComponent(AppComponent);
//     const app = fixture.componentInstance;
//     expect(app.title).toEqual('my-project-three-17v');
//   });

//   it('should render title', () => {
//     const fixture = TestBed.createComponent(AppComponent);
//     fixture.detectChanges();
//     const compiled = fixture.nativeElement as HTMLElement;
//     (<any>expect(compiled)).toMatchSnapshot();
//     // expect(compiled.querySelector('.content span')?.textContent).toContain(
//     //   'my-project-three-17v app is running!'
//     // );
//   });

//   it('should Dummy Snapshot Jest', () => {
//     fixture.detectChanges();
//     (<any>expect(fixture)).toMatchSnapshot();
//   });
// });
