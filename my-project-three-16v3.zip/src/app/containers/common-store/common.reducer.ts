import { addAboutFormReducer } from '../cms/store/reducers/about.reducer';
import { addHomeFormReducer } from '../cms/store/reducers/home.reducer';
import { reducerCmsProduct } from '../cms/store2/reducers/product.reducer';

import { addPurchaseReducer } from '../dashboard/store/reducers/purchase.reducer';
import { addSalesReducer } from '../dashboard/store/reducers/sales.reducer';

const dashboard = {
  sales: addSalesReducer,
  purchase: addPurchaseReducer,
};

const cms = {
  home: addHomeFormReducer,
  about: addAboutFormReducer,
  cmsproduct: reducerCmsProduct,
};


export { dashboard, cms };
