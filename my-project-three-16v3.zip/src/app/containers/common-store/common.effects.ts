import { CmsProductEffects } from '../cms/store2/effects/product.effects';
import { SalesEffects } from '../dashboard/store/effects/sales.effects';
import { PurchaseEffects } from '../dashboard/store/reducers/purchase.reducer';

const dashboardEffects = [PurchaseEffects, SalesEffects, CmsProductEffects];

// const cmsEffects = [];

export { dashboardEffects };
