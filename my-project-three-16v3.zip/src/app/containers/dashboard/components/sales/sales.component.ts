import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Sales, SalesState } from '../../models/sales.model';
import { CommonState } from '../../../common-store/common-state.model';
import {
  addSales,
  addSalesFailure,
  loadSales,
} from '../../store/actions/sales.actions';
import { selectSales } from '../../store/reducers/sales.reducer';

@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.scss'],
})
export class SalesComponent {
  sales: Observable<SalesState>;
  obserableSub: any;
  constructor(private store: Store<CommonState>) {
    this.sales = this.store.select(selectSales);
    // this.sales = this.store.select((state) => state.dashboard.sales);

    /* For Testing... */
    const observable = new Observable((observer) => {
      setInterval(() => {
        observer.next('Hello');
      }, 1000);
    });

    this.obserableSub = observable.subscribe(value => {
      console.log(value);
    });

  }

  addSales(name: string, priceInput: string) {
    const price = parseInt(priceInput);
    // this.store.dispatch({
    //   type: 'ADD_SALES',
    //   payload: <Sales>{
    //     name: name,
    //     price: price,
    //   },
    // });

    const payload: Sales[] = [{ name, price }];
    if (priceInput) {
      this.store.dispatch(addSales({ payload }));
    } else {
      this.store.dispatch(addSalesFailure({ payload: 'FAILED!!!' }));
    }
  }

  ngOnInit(): void {
    this.store.dispatch(loadSales());
  }

  ngOnDestroy(): void {
    this.obserableSub.unsubscribe();
  }
}
