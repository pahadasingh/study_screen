import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { Purchase } from '../../models/purchase.model';
import { CommonState } from 'src/app/containers/common-store/common-state.model';
import {
  addPurchase,
  delPurchase,
  loadItems,
  removeAllItemsSuccess,
  removeBulkItemsSuccess,
  selectPurchases,
  setBulkItems,
  updateBulkItemsSuccess,
  updateInsertBulkItems,
  updateInsertOneItems,
  updatePurchase,
} from '../../store/reducers/purchase.reducer';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.scss'],
})
export class PurchaseComponent {
  purchases!: Observable<Purchase[]>;

  constructor(private store: Store<CommonState>) {
    //this.purchases = this.store.select((state) => state.dashboard.purchase);
    this.purchases = this.store.select(selectPurchases);
  }

  ngOnInit(): void {
    this.store.dispatch(loadItems());
  }

  addPurchase(name: string, priceInput: string) {
    const price = parseInt(priceInput);
    // this.store.dispatch({
    //   type: '[Purchase] Add Purchase',
    //   payload: <Purchase>{name,price},
    // });
    //- this.store.dispatch( new AddPurchaseAction({name,price}) )

    const id = +new Date() + '';
    const payload: Purchase = { id, name, price };
    this.store.dispatch(addPurchase({ payload }));
  }

  updatePurchase() {
    const payload: Partial<Purchase> = { name: 'Iphone', price: 50000 };
    this.store.dispatch(updatePurchase({ id: '1', changes: payload }));
  }

  delPurchase() {
    this.store.dispatch(delPurchase({ id: '1' }));
  }
  

  updateBulkPurchase() {
    const payload: any = [
      { id: '1', changes: { name: 'Iphonessss', price: 1000 }},
      { id:'-1', changes: { name: 'AAAA', price: 1111 }},
      { id:'-2', changes: { name: 'BBBB', price: 2222 }}
    ];
    this.store.dispatch(updateBulkItemsSuccess({payload}) );
  }

  updateInsertBulkPurchase() {
    const payload: any = [
      { id: '1',  name: 'Iphonessss', price: 1000 },
      { id:'-1',  name: 'AAAA', price: 1111 },
      { id:'-2', name: 'BBBB', price: 22222 },
      { id:'-3', name: 'CCCC', price: 3333 }
    ];
    this.store.dispatch(updateInsertBulkItems({payload}) );
  }

  setBulkItemsPurchase() {
    const payload: any = [
      { id: '1',  name: 'Iphonessss', price: 1000 },
      { id:'2',  name: 'AAAA', price: 1111 },
      { id:'3', name: 'BBBB', price: 22222 },
      { id:'4', name: 'CCCC', price: 3333 }
    ];
    this.store.dispatch(setBulkItems({payload}) );
  }

  updateInsertOnePurchase() {
    const payload: any = { id:'-3', name: 'CCCCCCCC', price: 3333333 };
    this.store.dispatch(updateInsertOneItems({payload}) );
  }

  removeAllPurchase() {
    this.store.dispatch( removeAllItemsSuccess() );
  }

  removeSelectedPurchases() {
    const selectedTodoIds: string[] = ["1", "-1"];
    this.store.dispatch( removeBulkItemsSuccess({ ids: selectedTodoIds }));
  }
}
