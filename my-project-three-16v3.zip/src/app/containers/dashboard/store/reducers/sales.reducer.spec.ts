// import { Store, StoreModule } from '@ngrx/store';
// import { addSalesReducer, initialState, selectSales } from './sales.reducer';
// import { DashboardState } from '../../models/dashboad.state.model';
// import { TestBed } from '@angular/core/testing';
// import { CommonStoreModule } from 'src/app/containers/common-store/common-store.module';
// import { addSales } from '../actions/sales.actions';

// describe('Sales Reducer', () => {
//   let store: Store<DashboardState>;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [CommonStoreModule],
//     });

//     store = TestBed.inject(Store);
//   });

//   describe('an Add Sales action in Reducer', () => {

//     it('should return the initial state of sales item', () => {
//       const action = addSales as any;

//       const result = addSalesReducer(initialState, action);

//       expect(result).toBe(initialState);
//     });

//     it('should return the payload in state', () => {
//       const payload = [{ name: 'Product', price: 1000 }];

//       const action = addSales as any;

//       store.dispatch(action({ payload }));
//       store.select(selectSales).subscribe((result) => {
//         expect(result.data).toBe(payload);
//       });
//     });

//   });



// });
