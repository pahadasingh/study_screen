import { Injectable } from '@angular/core';
import { Action, createAction, createFeatureSelector, createReducer, createSelector, on, props } from '@ngrx/store';
import { Purchase } from '../../models/purchase.model';
import { DashboardState } from '../../models/dashboad.state.model';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, catchError, debounceTime, delay, map, mergeMap, of, tap } from 'rxjs';
import { EntityState, createEntityAdapter } from '@ngrx/entity';

// Initial state
export const initialState: Purchase[] = [
  {
    id: "1",
    name: 'Samsung',
    price: 1000,
  },
];

// export const ADD_PURCHASE = '[Purchase] Add Purchase';
// export const DEL_PURCHASE = '[Purchase] Del Purchase';

//#1. Action
// export class AddPurchaseAction implements Action {
//   readonly type = ADD_PURCHASE;
//   constructor(public payload: Purchase) {}
// }

// export class DeletePurchaseAction implements Action {
//   readonly type = DEL_PURCHASE;
//   constructor(public payload: string) {}
// }

//#2. Reducers
// export function addPurchaseReducer(state: Purchase[] = initialState, action: any) {
//   switch (action.type) {
//     case ADD_PURCHASE:
//       return [...state, action.payload];
//     case DEL_PURCHASE:
//       return state.filter((row) => row.name != action.payload)
//     default:
//       return state;
//   }
// }


//------------------------------------------------------

//1. Actions
export const addPurchase = createAction('[Purchase] Add Purchase',props<{payload: { id: string; name: string; price: number }}>());
export const delPurchase = createAction('[Purchase] Del Purchase',props<{id: string}>());
export const updatePurchase = createAction('[Purchase] Update Purchase',props<{ id: string, changes: Partial<Purchase>}>());

export const loadItems = createAction('[Purchase] Load Existing Purchases');
export const loadItemsFailure = createAction('[Purchase] Failure Purchase',props<{payload: string}>());
export const loadItemsSuccess = createAction('[Purchase] List Purchases Success',props<{payload: any[]}>());
export const updateBulkItemsSuccess = createAction('[Purchase] Update Bulk Purchases Success',props<{payload: any[]}>());
export const updateInsertBulkItems = createAction('[Purchase] Update-Insert Bulk Purchases',props<{payload: any[]}>());
export const setBulkItems = createAction('[Purchase] set Bulk Purchases',props<{payload: any[]}>());
export const updateInsertOneItems = createAction('[Purchase] Update-Insert One Purchases',props<{payload: { id: string; name: string; price: number }}>());
export const removeAllItemsSuccess = createAction('[Purchase] Remove All Purchases Success');
export const removeBulkItemsSuccess = createAction('[Purchase] Remove Bulk Purchases Success',props<{ids: any[]}>());


//2. Reducers
// export const addPurchaseReducer_OLD = createReducer(
//   initialState,
//   on(addPurchase, (state: Purchase[], { payload }) => [...state, payload] ),
//   on(updatePurchase, (state: Purchase[], { id, changes }: any) => [...state.map((row) => row.id == id ? {id, ...changes} : row )]),
//   on(delPurchase, (state: Purchase[], { id }) => state.filter((row) => row.id != id) ),
//   on(loadItemsSuccess, (state: Purchase[], { payload }) => [...state, ...payload] ),
//   on(loadItemsFailure, (state: Purchase[], action: any) => { console.log(action); return state; } ),
// );

//2'. Reducers Adapter
export const purchaseAdapter = createEntityAdapter<Purchase>();
export interface PurchaseState extends EntityState<Purchase> {}
export const initialPurchaseState: PurchaseState = purchaseAdapter.getInitialState({
  entities: { 1: initialState[0] },
  ids: [1],
});


export const addPurchaseReducer = createReducer(
  initialPurchaseState,
  on(addPurchase, (state: PurchaseState, { payload }) => purchaseAdapter.addOne(payload, state)),
  on(updatePurchase, (state: PurchaseState, { id, changes }) => purchaseAdapter.updateOne({ id, changes }, state)),
  on(delPurchase, (state: PurchaseState, { id }) => purchaseAdapter.removeOne(id, state)),
  on(loadItemsFailure, (state: PurchaseState, action: any) => { console.log(action); return state; } ),
  on(loadItemsSuccess, (state: PurchaseState, { payload }) => purchaseAdapter.addMany(payload, state)),
  on(updateBulkItemsSuccess, (state: PurchaseState, { payload }) => purchaseAdapter.updateMany(payload, state)),
  on(updateInsertBulkItems, (state: PurchaseState, { payload }) => purchaseAdapter.upsertMany(payload, state)),
  on(setBulkItems, (state: PurchaseState, { payload }) => purchaseAdapter.setMany(payload, state)),
  on(updateInsertOneItems, (state: PurchaseState, { payload }) => purchaseAdapter.upsertOne(payload, state)),
  on(removeAllItemsSuccess, (state: PurchaseState) => purchaseAdapter.removeAll(state) ),
  on(removeBulkItemsSuccess, (state: PurchaseState, { ids }) => purchaseAdapter.removeMany(ids, state)),
);


//3. Selectors
// export const selectPurchases_OLD = createSelector(
//   createFeatureSelector<DashboardState>('dashboard'),
//   (state) => state.purchase
// );

export const selectPurchases = createSelector(
  createFeatureSelector<DashboardState>('dashboard'),
  purchaseAdapter.getSelectors((state: any) => state.purchase).selectAll
);

//4. Effects
@Injectable()
export class PurchaseEffects {
 
  apiServiceItems: Observable<any[]> = of([{id:'-1', name: 'A', price: 1 }, {id:'-2', name: 'B', price: 2 }]).pipe(delay(2000));

  loadItems$ = createEffect(() => this.actions$.pipe(
    ofType(loadItems),
    debounceTime(300),
    mergeMap( () => this.apiServiceItems
      .pipe(
        tap(_ => console.warn),
        map(items => loadItemsSuccess({payload: items })),
        catchError(error => of(loadItemsFailure({ payload: error })))
      )
    )
  ));

  constructor(
    private actions$: Actions
  ) {}
}