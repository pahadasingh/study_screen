import { createFeatureSelector, createReducer, createSelector, on } from '@ngrx/store';
import { SalesState } from '../../models/sales.model';
import { addSales, addSalesFailure } from '../actions/sales.actions';
import { DashboardState } from '../../models/dashboad.state.model';

export const initialState: SalesState = {
  data: [{name: 'Samsung Sales',price: 1000}],
  status: 'SUCCESS'
};

export const addSalesReducer = createReducer(
  initialState,
  on(addSales, (state: SalesState, action: any) => ({...state, ...{data: [...state.data, ...action.payload], status: 'SUCCESS'}})),
  on(addSalesFailure, (state: SalesState, action: any) => ({...state, ...{status: action.payload}})),
);


//3. Selectors
export const selectSales = createSelector(
  createFeatureSelector<DashboardState>('dashboard'),
  (state) => state.sales
);