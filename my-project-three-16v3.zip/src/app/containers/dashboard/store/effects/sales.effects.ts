import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, catchError, debounceTime, delay, map, mergeMap, of, tap } from 'rxjs';
import { addSales, addSalesFailure, loadSales } from '../actions/sales.actions';


@Injectable()
export class SalesEffects {

  apiServiceItems: Observable<any[]> = of([{ name: 'A', price: 1 }, { name: 'B', price: 2 }]).pipe(delay(2000));
  
  loadSales$ = createEffect(() => this.actions$.pipe(
    ofType(loadSales),
    debounceTime(500),
    mergeMap( () => this.apiServiceItems
      .pipe(
        tap(_ => { console.warn(_) } ),
        map(items => addSales({payload: items })),
        catchError(error => of(addSalesFailure({ payload: 'FAILED' })))
      )
    ),
  ));

  constructor(private actions$: Actions) {}
}


// mergeMap( () => this.apiServiceItems.pipe(
//   tap(_ => console.warn),
//   map( items => alert(items) )
// ) )