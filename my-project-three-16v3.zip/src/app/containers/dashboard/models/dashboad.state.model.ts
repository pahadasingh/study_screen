import { PurchaseState } from "../store/reducers/purchase.reducer";
import { Purchase } from "./purchase.model";
import { SalesState } from "./sales.model";

export interface DashboardState {
  readonly purchase: PurchaseState; // Purchase - widhout adapter
  readonly sales: SalesState;
}