export interface Sales {
  name: string;
  price: number;
}

export interface SalesState {
  data: Sales[];
  status: string;
}
