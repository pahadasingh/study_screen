export interface Purchase {
  id: string;
  name: string;
  price: number;
}
