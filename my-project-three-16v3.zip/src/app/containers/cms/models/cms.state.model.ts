import { ProductState } from "../store2/reducers/product.reducer";
import { AboutForm } from "./about.model";
import { HomeForm } from "./home.model";

export interface CMSState {
  readonly home: HomeForm[];
  readonly about: AboutForm[];
  readonly cmsproduct: ProductState;
}
