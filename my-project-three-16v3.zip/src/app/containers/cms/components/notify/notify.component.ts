import { Component } from '@angular/core';
import { HttpService } from '../../services/http.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-notify',
  templateUrl: './notify.component.html',
  styleUrls: ['./notify.component.scss'],
})
export class NotifyComponent {
  listPosts: Observable<any[]> | undefined;
  constructor(public httpService: HttpService) {}

  ngOnInit(): void {
    this.listPosts = this.httpService.getPosts();
  }
}
