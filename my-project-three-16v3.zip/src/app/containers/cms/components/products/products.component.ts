import { Observable } from 'rxjs';
import { HttpService } from './../../services/http.service';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import {
  FIELD_TYPE,
  PRODUCT_FORM_FIELDS,
} from '../../constants/product.constant';

import { CommonState } from 'src/app/containers/common-store/common-state.model';
import { ProductActions } from '../../store2/actions/product.actions';
import { selectProducts } from '../../store2/reducers/product.reducer';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
})
export class ProductsComponent {

  FIELD_TYPE = FIELD_TYPE;
  formFields = PRODUCT_FORM_FIELDS;
  productForm: FormGroup;
  listCategorySub: any;
  
  keepOriginalOrder = (a: any, b: any) => a.key;

  constructor( private fb: FormBuilder, private store: Store<CommonState>, public httpService: HttpService ) {
    const formConfig = this.createFormConfig(this.formFields);
    this.productForm = this.fb.group(formConfig);
    // this.productForm = this.fb.group({
    //   category: ['', Validators.required],
    //   title: ['', Validators.required],
    //   price: [0, [Validators.required, Validators.min(0)]],
    //   description: [''],
    //   rating: [''],
    // });
    this.store.select(selectProducts);
  }



  ngOnInit(): void {
    this.listCategorySub = this.httpService.getCategory().subscribe((list: string[]) => {
        this.formFields['category'].options = list;
    });

    this.store.dispatch(ProductActions.clearProducts());
  }


  createFormConfig(fields: any): { [key: string]: any } {
    const config: { [key: string]: any } = {};

    for (const fieldName in fields) {
      if (fields.hasOwnProperty(fieldName)) {
        const fieldConfig = fields[fieldName];
        const validators = this.createValidators(fieldConfig.validators);
        const validations = {
          validators,
          disabled: fieldConfig?.disabled || false,
          readonly: fieldConfig?.readonly || false,
        };

        config[fieldName] = fieldConfig.type === 'checkbox' ? 
          this.fb.array([fieldConfig.initialValue]) : [fieldConfig.initialValue || '', validations];
      }
    }

    return config;
  }

  createValidators(validatorsConfig: any): Validators[] {
    const validators: Validators[] = [];

    validatorsConfig.required && validators.push(Validators.required);
    validatorsConfig.minLength && validators.push(Validators.minLength(validatorsConfig.minLength));
    validatorsConfig.maxLength && validators.push(Validators.maxLength(validatorsConfig.maxLength));
    validatorsConfig.email && validators.push(Validators.email);
    validatorsConfig.pattern && validators.push(Validators.pattern(validatorsConfig.pattern));

    return validators;
  }

  getValidationErrors(myForm: FormGroup, fieldName: string): string[] {
    const formControl = myForm.get(fieldName);
    const errors: string[] = [];

    if (formControl) {
      const { dirty, touched, errors: controlErrors } = formControl;

      if (dirty || touched) {
        for (const errorKey in controlErrors) {
          if (controlErrors.hasOwnProperty(errorKey)) {
            errors.push(this.getErrorMessage(fieldName, errorKey, controlErrors[errorKey]));
          }
        }
      }
    }

    return errors;
  }

  getErrorMessage(fieldName: string, errorKey: string, errorValue: any): string {
    // Customize error messages based on field name, error key, and error value
    switch (errorKey) {
      case 'required':
        return `${this.formFields[fieldName].label} is required`;
      case 'minlength':
        return `${this.formFields[fieldName].label} must be at least ${errorValue.requiredLength} characters`;
      case 'maxlength':
        return `${this.formFields[fieldName].label} cannot exceed ${errorValue.requiredLength} characters`;
      case 'email':
        return `Please enter a valid email address for ${this.formFields[fieldName].label}`;
      case 'pattern':
        return `${this.formFields[fieldName].label} must match the pattern: ${errorValue.requiredPattern}`;
      default:
        return `Validation error for ${this.formFields[fieldName].label}`;
    }
  }

  onSubmit() {
    if (this.productForm.valid) {
      const product = {

        id: new Date().getTime()+"",
        title: this.productForm.get('title')?.value,
        category: this.productForm.get('category')?.value,
        price: this.productForm.get('price')?.value,
        description: this.productForm.get('description')?.value,
        rating: this.productForm.get('rating')?.value,
      };

      this.store.dispatch(ProductActions.addProduct({product}));
    }
  }

  ngOnDestroy(): void {
    this.listCategorySub.unsubscribe();
  }
}
