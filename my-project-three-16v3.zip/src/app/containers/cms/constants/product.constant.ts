export enum FIELD_TYPE {
  SELECT = 'select',
  TEXT = 'text',
  NUMBER = 'number',
  EMAIL = 'email',
  CHECKBOX = 'checkbox',
  RADIO = 'radio',
  TEXTAREA = 'textarea',
}

export interface Validators {
  required?: boolean;
  email?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
}

export interface Fields {
  label: string;
  type: string;
  initialValue?: any;
  readOnly?: boolean;
  disabled?: boolean;
  options?: any[];
  validators?: Validators;
}

export const PRODUCT_FORM_FIELDS: Record<string, Fields> = {
  category: {
    label: 'Category',
    type: 'select',
    initialValue: '',
    options: [],
    validators: {
      required: true,
    },
  },
  title: {
    label: 'Name',
    type: 'text',
    initialValue: '',
    validators: {
      required: true,
      minLength: 3,
      maxLength: 50,
    },
  },
  price: {
    label: 'Price',
    type: 'number',
    initialValue: '',
    validators: {
      required: true,
      minLength: 1,
    },
  },
  description: {
    label: 'Description',
    type: 'textarea',
    initialValue: '',
    validators: {
      maxLength: 500,
    },
  },
  rating: {
    label: 'Ratings',
    type: 'radio',
    initialValue: 3,
    options: [0, 1, 2, 3, 4, 5],
    validators: {
    },
  },
  // Add more form fields as needed
};
