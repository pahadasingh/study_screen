import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class HttpService {

  readonly API_BASE_URL = 'https://fakestoreapi.com';

  constructor(private http: HttpClient) {}

  public getCategory(): Observable<any> {
    return this.http.get<any>(this.API_BASE_URL + '/products/categories');
  }

  public getProducts(): Observable<any> {
    return this.http.get<any>(this.API_BASE_URL + '/products');
  }

  public getPosts(): Observable<any> {
    return this.http.get<any>('https://jsonplaceholder.typicode.com/posts');
  }
}
