import { createActionGroup, emptyProps, props } from '@ngrx/store';

export const ProductsActions = createActionGroup({
  source: 'Products',
  events: {
    'Sraban Productss': emptyProps(),
    'Sraban Productss Success': props<{ data: unknown }>(),
    'Sraban Productss Failure': props<{ error: unknown }>(),
  }
});
