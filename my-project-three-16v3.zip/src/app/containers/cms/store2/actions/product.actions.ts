import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { Update } from '@ngrx/entity';

import { Product } from '../models/product.model';

export const ProductActions = createActionGroup({
  source: 'Product/API',
  events: {
    'Load Products': props<{ products: Product[] }>(),
    'Add Product': props<{ product: Product }>(),
    'Upsert Product': props<{ product: Product }>(),
    'Add Products': props<{ products: Product[] }>(),
    'Upsert Products': props<{ products: Product[] }>(),
    'Update Product': props<{ product: Update<Product> }>(),
    'Update Products': props<{ products: Update<Product>[] }>(),
    'Delete Product': props<{ id: string }>(),
    'Delete Products': props<{ ids: string[] }>(),
    'Clear Products': emptyProps(),
    'Cms Products': emptyProps(),
    'Cms Products Success': props<{ data: unknown }>(),
    'Cms Products Failure': props<{ error: unknown }>(),
  },
});
