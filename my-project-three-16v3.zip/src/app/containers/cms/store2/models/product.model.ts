export interface Product {
  id: string;
  category: string;
  title: string;
  price: string;
  description: string;
  rating: number;
}
