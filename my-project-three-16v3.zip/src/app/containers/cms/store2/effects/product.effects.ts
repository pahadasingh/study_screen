import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { Observable, EMPTY, of } from 'rxjs';
import { ProductActions } from '../actions/product.actions';


@Injectable()
export class CmsProductEffects {

  cmsProducts$ = createEffect(() => {
    return this.actions$.pipe(

      ofType(ProductActions.cmsProducts),
      concatMap(() =>
        /** An EMPTY observable only emits completion. Replace with your own observable API request */
        EMPTY.pipe(
          map(data => ProductActions.cmsProductsSuccess({ data })),
          catchError(error => of(ProductActions.cmsProductsFailure({ error }))))
      )
    );
  });


  constructor(private actions$: Actions) {}
}
