import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { PushComponent } from './push.component';
import { ServiceWorkerModule, SwPush, SwUpdate } from '@angular/service-worker';
import { NotificationService } from './notifications.service';

describe('PushComponent', () => {
  let component: PushComponent;
  let fixture: ComponentFixture<PushComponent>;
  // let store: MockStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, ServiceWorkerModule.register('', { enabled: false })],
      declarations: [PushComponent],
      providers: [
        MockStore,
        SwUpdate,
        SwPush,
        NotificationService,
        provideMockStore({}),
      ],
    });

    fixture = TestBed.createComponent(PushComponent);
    component = fixture.componentInstance;

    TestBed.inject(MockStore);
    TestBed.inject(SwUpdate);
    TestBed.inject(SwPush);
    TestBed.inject(NotificationService);
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(PushComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'my-project-three-17v'`, () => {
    const fixture = TestBed.createComponent(PushComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('my-project-three-17v');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(PushComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    (<any>expect(compiled)).toMatchSnapshot();
    // expect(compiled.querySelector('.content span')?.textContent).toContain(
    //   'my-project-three-17v app is running!'
    // );
  });

  it('should Dummy Snapshot Jest', () => {
    fixture.detectChanges();
    (<any>expect(fixture)).toMatchSnapshot();
  });
});
