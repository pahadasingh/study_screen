import { Contact } from '../../models/contact.model';
import { ContactActionTypes, ContactActions } from '../actions/contact.action';

export const initialState: Contact = {
  name: 'Initial Name',
  email: 'initial-email@email.dom'
};

export function ContactReducer(state: Contact = initialState, action: ContactActions) {
  switch (action.type) {
    case ContactActionTypes.ADD_CONTACT:
      return { ...state, ...action.payload };
    case ContactActionTypes.DELETE_CONTACT:
      return {};
    default:
      return state;
  }
}
