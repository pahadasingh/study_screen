import { Component } from '@angular/core';
import { AppState } from './models/app.state.model';
import { Store } from '@ngrx/store';
import { selectUrl } from './store/selectors/router.selectors';

export const PUBLIC_VAPID_KEY_OF_SERVER = 'BLJJGwiEene6WWaZ_mMiD1CovYb3a-SRj9dmOzqsyduWAKl82RU1HXxHJDoOSZl9RYPtmNmPR3JZf1Ppt7ul70Q';
import {
  SwPush,
  SwUpdate,
  UnrecoverableStateEvent,
  VersionEvent,
  VersionReadyEvent,
} from '@angular/service-worker';
import { NotificationService } from './notifications.service';

@Component({
  selector: 'push-root',
  templateUrl: './push.component.html',
})
export class PushComponent {
  title = 'my-project-three-17v';

  notificationData: string = '{   "notification": {       "title": "Sraban",       "body": "Testing..."   } }';
  constructor(private store: Store<AppState>,
    private updateService: SwUpdate,
    private pushService: SwPush,
    private notificationService: NotificationService) {
    // this.store.select('router').subscribe(data => console.log(data) );
    this.store.select(selectUrl).subscribe(url => console.log(url) );
  }

  ngOnInit() {
    console.log('AppComponent.ngOnInit');
    if (!this.updateService.isEnabled) {
      console.log('AppComponent.ngOnInit: Service Worker is not enabled');
      return;
    }
    console.log('AppComponent.ngOnInit: Service Worker is enabled');
    this.#handleUpdates();
    this.#handleNotifications();
  }

  unsubscribe() {
    this.pushService.unsubscribe().then(() => {
      console.log('Unsubscribed');
    });
  }
  sendNotification() {
    this.notificationService.notifications(this.notificationData);
  }

  #handleUpdates() {
    this.updateService.versionUpdates.subscribe((event: VersionEvent) => {
      console.log(event);
      alert(event.type);
      if (
        event.type === 'VERSION_READY' &&
        confirm(
          `New version ${
            (event as VersionReadyEvent).latestVersion.hash
          } available. Load New Version?`
        )
      ) {
        window.location.reload();
      }
    });
    // const interval = setInterval(async () => {
    //   const shouldUpdate = await this.updateService.checkForUpdate();
    //   alert('Checked for update with result: ' + shouldUpdate);
    //   if (shouldUpdate) {
    //     const result = await this.updateService.activateUpdate();
    //     alert('Activate Update completed with result: ' + result);
    //     clearInterval(interval);
    //   }
    // }, 1000);

    this.updateService.unrecoverable.subscribe(
      (event: UnrecoverableStateEvent) => {
        alert('Error reason : ' + event.reason);
      }
    );
  }

  async #handleNotifications() {
    
    try {
      const sub = await this.pushService.requestSubscription({
        serverPublicKey: PUBLIC_VAPID_KEY_OF_SERVER,
      });
      this.notificationService.addSubscription(sub);
      console.log('sraban Subscribed');
    } catch (err) {
      console.error('Could not subscribe due to:', err);
    }
    this.pushService.messages.subscribe((message) => {
      console.log("messages", message);
    });
    this.pushService.notificationClicks.subscribe((message) => {
      console.log("notificationClicks", message);
    });
    this.pushService.subscription.subscribe((subscription) => {
      console.log("subscription", subscription);
    });
  }
}
