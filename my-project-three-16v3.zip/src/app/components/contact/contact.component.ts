import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AppState } from 'src/app/models/app.state.model';
import { Contact } from 'src/app/models/contact.model';
import { AddContactAction } from '@appStore/actions/contact.action';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss'],
})
export class ContactComponent {
  contacts: Observable<Contact>;

  constructor(private store: Store<AppState>) {
    this.contacts = this.store.select((state) => state.contact);
  }

  addContact(name: string, email: string) {
    // this.store.dispatch({
    //   type: '[CONTACT] ADD',
    //   payload: <Contact>{
    //     name: name,
    //     email: email,
    //   },
    // });

    this.store.dispatch(
      new AddContactAction({
        name: name,
        email: email,
      })
    );
    
  }
}
