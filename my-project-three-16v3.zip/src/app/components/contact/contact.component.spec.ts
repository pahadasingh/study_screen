import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactComponent } from './contact.component';
import {
  MockStore,
  MockStoreConfig,
  provideMockStore,
} from '@ngrx/store/testing';
import { AppState } from 'src/app/models/app.state.model';
import { Store } from '@ngrx/store';
import { AddContactAction } from '@appStore/actions/contact.action';
import { initialState } from '@appStore/reducers/contact.reducer';

declare function expect(expectedParameter: any): any;

const initialStateMock = {
  product: [],
  contact: initialState,
  router: {} as any,
} as MockStoreConfig<AppState>;

describe('ContactComponent', () => {
  let component: ContactComponent;
  let fixture: ComponentFixture<ContactComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ContactComponent],
      imports: [],
      providers: [MockStore, provideMockStore({ ...initialStateMock })],
    });
    fixture = TestBed.createComponent(ContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    TestBed.inject(MockStore);
    TestBed.inject(Store);
  });

  it('should create 1', () => {
    expect(component).toBeTruthy();
  });

  it('should match the existing page', () => {
    fixture.detectChanges();
    expect(fixture).toMatchSnapshot();
  });

  it('should create AddContactAction action', () => {
    let action: AddContactAction = new AddContactAction(initialState);
    expect(action).toMatchSnapshot();
  });
});
