// global.d.ts

// Extend JestMatchers interface
declare namespace jest {
  interface Matchers<R> {
    toMatchSnapshot(expectedParameter: any): R;
  }
}

declare namespace jest {
  interface Matchers<R> {
    expect(expectedParameter: any): R;
  }
}
