import { RouterReducerState } from '@ngrx/router-store';
import { createFeatureSelector, createSelector } from '@ngrx/store';

export const selectRouterState = createFeatureSelector<RouterReducerState<any>>('router');

export const selectUrl = createSelector(
  selectRouterState,
  (router) => router?.state?.url
);

// Add more selectors as needed
