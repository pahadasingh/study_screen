import { Action } from '@ngrx/store';
import { Contact } from '../../models/contact.model';

export enum ContactActionTypes  {
  ADD_CONTACT = '[CONTACT] ADD',
  DELETE_CONTACT = '[CONTACT] DELETE',
}

export class AddContactAction implements Action {
  readonly type = ContactActionTypes.ADD_CONTACT;
  constructor(public payload: Contact) {}
}

export class DeleteContactAction implements Action {
  readonly type = ContactActionTypes.DELETE_CONTACT;
  constructor(public payload: string) {}
}

export type ContactActions = AddContactAction | DeleteContactAction | any;