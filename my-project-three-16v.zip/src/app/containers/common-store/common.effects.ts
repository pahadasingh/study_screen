import { PurchaseEffects } from '../dashboard/store/reducers/purchase.reducer';

const dashboardEffects = [PurchaseEffects];

// const cmsEffects = [];

export { dashboardEffects };
