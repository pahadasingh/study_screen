import { createFeature, createReducer, on } from '@ngrx/store';
import { ProductsActions } from '../actions/products.actions';

export const productsFeatureKey = 'products';

export interface State {

}

export const initialState: State = {

};

export const reducer = createReducer(
  initialState,
  on(ProductsActions.srabanProductss, state => state),
  on(ProductsActions.srabanProductssSuccess, (state, action) => state),
  on(ProductsActions.srabanProductssFailure, (state, action) => state),
);

export const productsFeature = createFeature({
  name: productsFeatureKey,
  reducer,
});

