import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { Observable, EMPTY, of } from 'rxjs';
import { ProductsActions } from '../actions/products.actions';


@Injectable()
export class ProductsEffects {

  srabanProductss$ = createEffect(() => {
    return this.actions$.pipe(

      ofType(ProductsActions.srabanProductss),
      concatMap(() =>
        /** An EMPTY observable only emits completion. Replace with your own observable API request */
        EMPTY.pipe(
          map(data => ProductsActions.srabanProductssSuccess({ data })),
          catchError(error => of(ProductsActions.srabanProductssFailure({ error }))))
      )
    );
  });


  constructor(private actions$: Actions) {}
}
