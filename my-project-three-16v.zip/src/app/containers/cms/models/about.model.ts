export interface AboutForm {
  name: string;
  topics: string;
}
