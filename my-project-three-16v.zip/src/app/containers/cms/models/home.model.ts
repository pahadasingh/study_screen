export interface HomeForm {
  name: string;
  mobile: string;
}
