import { Purchase } from "./purchase.model";
import { Sales } from "./sales.model";

export interface DashboardState {
  readonly purchase: Purchase[];
  readonly sales: Sales[];
}