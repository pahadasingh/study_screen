export interface Sales {
    name: string;
    price: number;
  }