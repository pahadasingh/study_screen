import { createActionGroup, emptyProps, props } from '@ngrx/store';

export const AddSalesActions = createActionGroup({
  source: 'Sales',
  events: {
    '[Sales] Add Sales': props<{payload: { name: string; price: number }}>(),
    '[Sales] Load AddSaless Success': props<{ data: unknown }>(),
    '[Sales] Load AddSaless Failure': emptyProps(),
  }
});
