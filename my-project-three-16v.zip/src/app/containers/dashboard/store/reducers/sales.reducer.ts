import { Sales } from '../../models/sales.model';
import { Action } from '@ngrx/store';

export const ADD_SALES = 'ADD_SALES';

export function addSalesReducer(state: Sales[] = [], action: any) {
  switch (action.type) {
    case ADD_SALES:
        return [...state, action.payload];
    default:
        return state;
    }
}