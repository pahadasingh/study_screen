import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { DashboardState } from '../../models/dashboad.state.model';
import { Purchase } from '../../models/purchase.model';
import { CommonState } from 'src/app/containers/common-store/common-state.model';
import { addPurchase, loadItems, selectPurchases } from '../../store/reducers/purchase.reducer';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.scss'],
})
export class PurchaseComponent {
  purchases: Observable<Purchase[]>;

  constructor(private store: Store<CommonState>) {
    //this.purchases = this.store.select((state) => state.dashboard.purchase);
    this.purchases = this.store.select(selectPurchases);
  }

  ngOnInit(): void {
    this.store.dispatch( loadItems() );
  }

  addPurchase(name: string, priceInput: string) {
    const price = parseInt(priceInput);
    // this.store.dispatch({
    //   type: '[Purchase] Add Purchase',
    //   payload: <Purchase>{name,price},
    // });

    const payload: Purchase = { name, price };
    this.store.dispatch( addPurchase({ payload }) );
  }
}
