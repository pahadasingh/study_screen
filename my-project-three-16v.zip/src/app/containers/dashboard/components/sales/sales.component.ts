import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Sales } from '../../models/sales.model';
import { CommonState } from '../../../common-store/common-state.model';

@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.scss'],
})
export class SalesComponent {
  sales: Observable<Sales[]>;

  constructor(private store: Store<CommonState>) {
    this.sales = this.store.select((state) => state.dashboard.sales);
  }

  addSales(name: string, priceInput: string) {
    const price = parseInt(priceInput);
    this.store.dispatch({
      type: 'ADD_SALES',
      payload: <Sales>{
        name: name,
        price: price,
      },
    });
  }
}
