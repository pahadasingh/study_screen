import { RouterReducerState } from "@ngrx/router-store";
import { Contact } from "./contact.model";
import { Product } from "./product.model";

export interface AppState {
  readonly product: Product[];
  readonly contact: Contact;
  readonly router: RouterReducerState<any>; // based on your specific use case if you have a custom router state
}