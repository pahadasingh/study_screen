import { Component } from '@angular/core';
import { AppState } from './models/app.state.model';
import { Store } from '@ngrx/store';
import { selectUrl } from './store/selectors/router.selectors';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'my-project-three-17v';

  constructor(private store: Store<AppState>) {
    // this.store.select('router').subscribe(data => console.log(data) );
    this.store.select(selectUrl).subscribe(url => console.log(url) );
  }
}
