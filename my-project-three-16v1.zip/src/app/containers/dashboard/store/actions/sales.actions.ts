import { createAction, props } from '@ngrx/store';

export const loadSales = createAction('[Sales] Load Sales');
export const addSales = createAction('[Sales] Add Sales',props<{payload: { name: string; price: number }[]}>() );
export const addSalesFailure = createAction('[Sales] Load AddSaless Failure', props<{ payload: unknown }>());


export const SalesActions = {
  loadSales,
  addSales,
  addSalesFailure
}