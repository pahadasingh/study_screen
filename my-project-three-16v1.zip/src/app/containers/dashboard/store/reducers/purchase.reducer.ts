import { Injectable } from '@angular/core';
import { Action, createAction, createFeatureSelector, createReducer, createSelector, on, props } from '@ngrx/store';
import { Purchase } from '../../models/purchase.model';
import { DashboardState } from '../../models/dashboad.state.model';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, catchError, debounceTime, delay, map, mergeMap, of, tap } from 'rxjs';

// Initial state
export const initialState: Purchase[] = [
  {
    name: 'Samsung',
    price: 1000,
  },
];

// export const ADD_PURCHASE = '[Purchase] Add Purchase';
// export const DEL_PURCHASE = '[Purchase] Del Purchase';

//#1. Action
// export class AddContactAction implements Action {
//   readonly type = ADD_PURCHASE;
//   constructor(public payload: Purchase) {}
// }

// export class DeleteContactAction implements Action {
//   readonly type = DEL_PURCHASE;
//   constructor(public payload: string) {}
// }

//#2. Reducers
// export function addPurchaseReducer(state: Purchase[] = initialState, action: any) {
//   switch (action.type) {
//     case ADD_PURCHASE:
//       return [...state, action.payload];
//     case DEL_PURCHASE:
//       return state.filter((row) => row.name != action.payload)
//     default:
//       return state;
//   }
// }


//------------------------------------------------------

//1. Actions
export const addPurchase = createAction('[Purchase] Add Purchase',props<{payload: { name: string; price: number }}>());
export const delPurchase = createAction('[Purchase] Del Purchase',props<{payload: string}>());
export const loadItems = createAction('[Purchase] Load Existing Purchases');
export const loadItemsSuccess = createAction('[Purchase] List Purchases Success',props<{payload: any[]}>());
export const loadItemsFailure = createAction('[Purchase] Failure Purchase',props<{payload: string}>());


//2. Reducers
export const addPurchaseReducer = createReducer(
  initialState,
  on(addPurchase, (state: Purchase[], action: any) => [...state, action.payload] ),
  on(delPurchase, (state: Purchase[], action: any) => state.filter((row) => row.name != action.payload) ),
  on(loadItemsSuccess, (state: Purchase[], action: any) => [...state, ...action.payload] ),
  on(loadItemsFailure, (state: Purchase[], action: any) => { console.log(action.payload); return state; } ),
);


//3. Selectors
export const selectPurchases = createSelector(
  createFeatureSelector<DashboardState>('dashboard'),
  (state) => state.purchase
);


//4. Effects
@Injectable()
export class PurchaseEffects {
 
  apiServiceItems: Observable<any[]> = of([{ name: 'A', price: 1 }, { name: 'B', price: 2 }]).pipe(delay(2000));

  loadItems$ = createEffect(() => this.actions$.pipe(
    ofType(loadItems),
    debounceTime(300),
    mergeMap( () => this.apiServiceItems
      .pipe(
        tap(_ => console.warn),
        map(items => loadItemsSuccess({payload: items })),
        catchError(error => of(loadItemsFailure({ payload: error })))
      )
    )
  ));

  constructor(
    private actions$: Actions
  ) {}
}