export interface Purchase {
    name: string;
    price: number;
  }