import { Action } from '@ngrx/store';
import { HomeForm } from '../../models/home.model';

export const ADD_HOME_FORM = 'ADD_HOME_FORM';

export function addHomeFormReducer(state: HomeForm[] = [], action: any) {
  switch (action.type) {
    case ADD_HOME_FORM:
      return [...state, action.payload];
    default:
      return state;
  }
}
