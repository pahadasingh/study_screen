import { Action } from '@ngrx/store';
import { AboutForm } from '../../models/about.model';

export const ADD_ABOUT_FORM = 'ADD_ABOUT_FORM';

export function addAboutFormReducer(state: AboutForm[] = [], action: any) {
  switch (action.type) {
    case ADD_ABOUT_FORM:
        return [...state, action.payload];
    default:
        return state;
    }
}
