import { SalesEffects } from '../dashboard/store/effects/sales.effects';
import { PurchaseEffects } from '../dashboard/store/reducers/purchase.reducer';

const dashboardEffects = [PurchaseEffects, SalesEffects];

// const cmsEffects = [];

export { dashboardEffects };
