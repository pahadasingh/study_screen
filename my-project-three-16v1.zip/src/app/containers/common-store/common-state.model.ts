import { CMSState } from "../cms/models/cms.state.model";
import { DashboardState } from "../dashboard/models/dashboad.state.model";

export interface CommonState {
  // Define common state properties
  dashboard: DashboardState;
  cms: CMSState;
}
