// common-store.module.ts
import { NgModule } from '@angular/core';
import { Action, StoreModule } from '@ngrx/store';
import { cms, dashboard } from './common.reducer';
import { dashboardEffects } from './common.effects';
import { EffectsModule } from '@ngrx/effects';
import { DashboardState } from '../dashboard/models/dashboad.state.model';
import { CMSState } from '../cms/models/cms.state.model';

@NgModule({
  imports: [
    StoreModule.forFeature<CMSState, Action>('cms', cms),
    StoreModule.forFeature<DashboardState, Action>('dashboard', dashboard),
    EffectsModule.forFeature([...dashboardEffects]),
  ],
})
export class CommonStoreModule {}
