# MyProjectThree17v

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.0.0.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.


=============================================================================================
    https://v8.ngrx.io/guide/schematics 

    https://www.slideshare.net/ChristofferNoring/ngrx-slides 

    ### NGRX SCHEMA ###
    
    npm install @ngrx/{store,effects,entity,store-devtools} --save --force
    ng g @ngrx/schematics:store State --root --module app.module.ts
    ng g @ngrx/schematics:store State --root --module app.module.ts --collection
    ng g @ngrx/schematics:effect App --root --module app.module.ts --collection


    ###ng g @ngrx/schematics:feature --help
    ng g @ngrx/schematics:feature products --group (Ruby Structure)

    ng g @ngrx/schematics:action ACTION_NAME(like User)
    ng g @ngrx/schematics:effect EFFECT_NAME --module cms.module.ts
    ng g @ngrx/schematics:reducer REDUCER_NAME
    ng g @ngrx/schematics:entity ENTITY_NAME
    ng g @ngrx/schematics:container TodoList (componet is created along with store injected)
==============================================================================================